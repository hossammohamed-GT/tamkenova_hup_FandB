-- ============================================================
-- Tamkeenova Student Module Migration
-- Run this on Neon (PostgreSQL)
-- ============================================================

-- ==================== NEW ENUMS ====================

CREATE TYPE "enrollment_status" AS ENUM ('ACTIVE', 'COMPLETED', 'CANCELLED', 'SUSPENDED');

CREATE TYPE "consultation_status" AS ENUM ('PENDING', 'APPROVED', 'REJECTED', 'SCHEDULED', 'COMPLETED', 'CANCELLED');

CREATE TYPE "corporate_status" AS ENUM ('PENDING', 'UNDER_REVIEW', 'ASSIGNED', 'APPROVED', 'REJECTED', 'COMPLETED');


-- ==================== ALTER EXISTING TABLES ====================

-- Add new columns to users table
ALTER TABLE "users"
  ADD COLUMN "bio"             VARCHAR(500),
  ADD COLUMN "location"        VARCHAR(255),
  ADD COLUMN "whatsapp"        VARCHAR(30),
  ADD COLUMN "website_url"     VARCHAR(500),
  ADD COLUMN "linkedin_url"    VARCHAR(500),
  ADD COLUMN "total_training_hours" INTEGER DEFAULT 0;

-- Add new columns to notifications table
ALTER TABLE "notifications"
  ADD COLUMN "type"            VARCHAR(50),
  ADD COLUMN "reference_id"    UUID,
  ADD COLUMN "reference_type"  VARCHAR(50);


-- ==================== NEW TABLES ====================

-- ==============================
-- 1. student_enrollments
-- ==============================
CREATE TABLE "student_enrollments" (
  "id"             UUID NOT NULL DEFAULT gen_random_uuid(),
  "student_id"     UUID NOT NULL,
  "program_id"     UUID NOT NULL,
  "status"         "enrollment_status" NOT NULL DEFAULT 'ACTIVE',
  "enrolled_at"    TIMESTAMPTZ(6) NOT NULL DEFAULT now(),
  "completed_at"   TIMESTAMPTZ(6),
  "cancelled_at"   TIMESTAMPTZ(6),
  "trainer_notes"  TEXT,
  "progress"       INTEGER DEFAULT 0,

  CONSTRAINT "student_enrollments_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "student_enrollments_student_program_unique" UNIQUE ("student_id", "program_id"),
  CONSTRAINT "fk_enrollment_student" FOREIGN KEY ("student_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT "fk_enrollment_program" FOREIGN KEY ("program_id") REFERENCES "training_programs"("id") ON DELETE CASCADE ON UPDATE NO ACTION
);

CREATE INDEX "idx_enrollments_student" ON "student_enrollments"("student_id");
CREATE INDEX "idx_enrollments_program" ON "student_enrollments"("program_id");
CREATE INDEX "idx_enrollments_status"  ON "student_enrollments"("status");


-- ==============================
-- 2. certificates (student certificates)
-- ==============================
CREATE TABLE "certificates" (
  "id"                UUID NOT NULL DEFAULT gen_random_uuid(),
  "student_id"        UUID NOT NULL,
  "trainer_id"        UUID NOT NULL,
  "program_id"        UUID NOT NULL,
  "enrollment_id"     UUID,
  "verification_code" VARCHAR(20) NOT NULL,
  "title"             VARCHAR(255) NOT NULL,
  "description"       TEXT,
  "pdf_url"           TEXT,
  "qr_code_url"       TEXT,
  "issued_at"         TIMESTAMPTZ(6) NOT NULL DEFAULT now(),
  "is_valid"          BOOLEAN DEFAULT true,
  "training_hours"    INTEGER DEFAULT 0,

  CONSTRAINT "certificates_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "certificates_verification_code_key" UNIQUE ("verification_code"),
  CONSTRAINT "fk_certificate_student"   FOREIGN KEY ("student_id")   REFERENCES "users"("id")              ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT "fk_certificate_trainer"   FOREIGN KEY ("trainer_id")   REFERENCES "trainers"("id")           ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT "fk_certificate_program"   FOREIGN KEY ("program_id")   REFERENCES "training_programs"("id")  ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT "fk_certificate_enrollment" FOREIGN KEY ("enrollment_id") REFERENCES "student_enrollments"("id") ON DELETE SET NULL ON UPDATE NO ACTION
);

CREATE INDEX "idx_certificates_student"          ON "certificates"("student_id");
CREATE INDEX "idx_certificates_trainer"          ON "certificates"("trainer_id");
CREATE INDEX "idx_certificates_verification"     ON "certificates"("verification_code");
CREATE INDEX "idx_certificates_program"          ON "certificates"("program_id");


-- ==============================
-- 3. consultations
-- ==============================
CREATE TABLE "consultations" (
  "id"                      UUID NOT NULL DEFAULT gen_random_uuid(),
  "student_id"              UUID NOT NULL,
  "trainer_id"              UUID NOT NULL,
  "title"                   VARCHAR(255) NOT NULL,
  "description"             TEXT NOT NULL,
  "preferred_date"          DATE,
  "preferred_time"          VARCHAR(20),
  "status"                  "consultation_status" NOT NULL DEFAULT 'PENDING',
  "price"                   DECIMAL(10,2),
  "trainer_notes"           TEXT,
  "student_notes"           TEXT,
  "scheduled_at"            TIMESTAMPTZ(6),
  "completed_at"            TIMESTAMPTZ(6),
  "contact_phone"           VARCHAR(30),
  "preferred_contact_method" VARCHAR(20),
  "rejection_reason"        TEXT,
  "created_at"              TIMESTAMPTZ(6) NOT NULL DEFAULT now(),
  "updated_at"              TIMESTAMPTZ(6) NOT NULL DEFAULT now(),

  CONSTRAINT "consultations_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "fk_consultation_student" FOREIGN KEY ("student_id") REFERENCES "users"("id")    ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT "fk_consultation_trainer" FOREIGN KEY ("trainer_id") REFERENCES "trainers"("id") ON DELETE CASCADE ON UPDATE NO ACTION
);

CREATE INDEX "idx_consultations_student" ON "consultations"("student_id");
CREATE INDEX "idx_consultations_trainer" ON "consultations"("trainer_id");
CREATE INDEX "idx_consultations_status"  ON "consultations"("status");


-- ==============================
-- 4. consultation_reviews
-- ==============================
CREATE TABLE "consultation_reviews" (
  "id"              UUID NOT NULL DEFAULT gen_random_uuid(),
  "consultation_id" UUID NOT NULL,
  "student_id"      UUID NOT NULL,
  "rating"          INTEGER NOT NULL,
  "comment"         TEXT,
  "created_at"      TIMESTAMPTZ(6) NOT NULL DEFAULT now(),

  CONSTRAINT "consultation_reviews_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "consultation_reviews_consultation_key" UNIQUE ("consultation_id"),
  CONSTRAINT "fk_consultation_review_consultation" FOREIGN KEY ("consultation_id") REFERENCES "consultations"("id") ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT "fk_consultation_review_student"      FOREIGN KEY ("student_id")      REFERENCES "users"("id")          ON DELETE CASCADE ON UPDATE NO ACTION
);

CREATE INDEX "idx_consultation_reviews_student" ON "consultation_reviews"("student_id");


-- ==============================
-- 5. corporate_requests
-- ==============================
CREATE TABLE "corporate_requests" (
  "id"                   UUID NOT NULL DEFAULT gen_random_uuid(),
  "requester_id"         UUID NOT NULL,

  -- Contact info
  "contact_name"         VARCHAR(255) NOT NULL,
  "contact_email"        VARCHAR(255) NOT NULL,
  "contact_phone"        VARCHAR(30),
  "contact_whatsapp"     VARCHAR(30),

  -- Company info
  "company_name"         VARCHAR(255) NOT NULL,
  "sector"               VARCHAR(255),
  "country"              VARCHAR(100),
  "employees_count"      INTEGER,

  -- Service
  "service_type"         VARCHAR(100) NOT NULL,
  "service_description"  TEXT NOT NULL,
  "expected_budget"      VARCHAR(100),
  "project_duration"     VARCHAR(100),

  -- Status
  "status"               "corporate_status" NOT NULL DEFAULT 'PENDING',
  "admin_notes"          TEXT,
  "assigned_to"          UUID,
  "rejection_reason"     TEXT,

  "created_at"           TIMESTAMPTZ(6) NOT NULL DEFAULT now(),
  "updated_at"           TIMESTAMPTZ(6) NOT NULL DEFAULT now(),

  CONSTRAINT "corporate_requests_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "fk_corporate_requester"  FOREIGN KEY ("requester_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT "fk_corporate_assigned"   FOREIGN KEY ("assigned_to")  REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE NO ACTION
);

CREATE INDEX "idx_corporate_requests_requester" ON "corporate_requests"("requester_id");
CREATE INDEX "idx_corporate_requests_status"    ON "corporate_requests"("status");


-- ==============================
-- 6. corporate_request_attachments
-- ==============================
CREATE TABLE "corporate_request_attachments" (
  "id"          UUID NOT NULL DEFAULT gen_random_uuid(),
  "request_id"  UUID NOT NULL,
  "file_name"   VARCHAR(255) NOT NULL,
  "file_url"    TEXT NOT NULL,
  "file_type"   VARCHAR(50) NOT NULL,
  "created_at"  TIMESTAMPTZ(6) NOT NULL DEFAULT now(),

  CONSTRAINT "corporate_request_attachments_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "fk_attachment_request" FOREIGN KEY ("request_id") REFERENCES "corporate_requests"("id") ON DELETE CASCADE ON UPDATE NO ACTION
);

CREATE INDEX "idx_corporate_attachments_request" ON "corporate_request_attachments"("request_id");


-- ==============================
-- 7. student_skills
-- ==============================
CREATE TABLE "student_skills" (
  "id"         UUID NOT NULL DEFAULT gen_random_uuid(),
  "student_id" UUID NOT NULL,
  "skill_name" VARCHAR(255) NOT NULL,
  "source"     VARCHAR(50),
  "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT now(),

  CONSTRAINT "student_skills_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "student_skills_student_skill_unique" UNIQUE ("student_id", "skill_name"),
  CONSTRAINT "fk_skill_student" FOREIGN KEY ("student_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE NO ACTION
);

CREATE INDEX "idx_student_skills_student" ON "student_skills"("student_id");
